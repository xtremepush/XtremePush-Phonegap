cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.xtreme.plugins.XtremePush/www/xtremepush.js",
        "id": "com.xtreme.plugins.XtremePush.XTremePush",
        "clobbers": [
            "XTremePush"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.xtreme.plugins.XtremePush": "1.1.0"
}
// BOTTOM OF METADATA
});