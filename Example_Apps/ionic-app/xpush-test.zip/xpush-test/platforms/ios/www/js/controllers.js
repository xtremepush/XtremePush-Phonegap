angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope,$xpush) {
	
	/**
	 * event called when registrtaion methdo is called
	 */
	$scope.register = function(){
		$xpush.register(successCallback, failCallback, { alert:true, badge:true, sound:true});
	}

	$scope.unregister = function(){
		$xpush.unregister(successCallback, failCallback);
	}

	$scope.isSandboxModeOn = function(){
		$xpush.isSandboxModeOn(successCallback, failCallback);
	}

	$scope.version = function(){
		$xpush.version(successCallback, failCallback);
	}

	$scope.shouldWipeBadgeNumber = function(){
		$xpush.shouldWipeBadgeNumber(successCallback, failCallback);
	}

	$scope.setLocationEnabled = function(){
		$xpush.setLocationEnabled(successCallback, failCallback, true);
	}

	$scope.showPushListController = function(){
		$xpush.showPushListController(successCallback, failCallback);
	}

	$scope.getPushNotificationsOffset = function(){
		$xpush.getPushNotificationsOffset(successCallback, failCallback, 5, 10);
	}
            
    $scope.$on('$cordovaPush:notificationReceived', function(data){
       alert('success');
   	})

	function successCallback(res){
		alert(res);
	}

	function failCallback(res){
		alert(res);	
	}


})
